package com.example.service;



import com.example.domain.TradeVO;

public interface TradeService {
	public void insert(TradeVO vo);
}
