package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.TradeVO;
import com.example.mapper.AccountMapper;
import com.example.mapper.TradeMapper;

@Service
public class TradeServiceImpl implements TradeService{
	@Autowired
	TradeMapper mapper;
	
	@Autowired
	AccountMapper aMapper;
	
	@Transactional
	@Override
	public void insert(TradeVO vo) {
		//���
		mapper.insert(vo);
		aMapper.update(vo.getAno(), vo.getAmount()*-1);
		
		//�Ա�
		vo.setType("0");
		String no=vo.getAno();
		String tradeNo=vo.getTradeNo();
		vo.setAno(vo.getTradeNo());
		vo.setTradeNo(no);
		mapper.insert(vo);
		aMapper.update(tradeNo, vo.getAmount());
	}
	
}
